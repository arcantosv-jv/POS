from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy import func
import bcrypt
import uuid

db = SQLAlchemy()

class User(db.Model):
    """Modelo de usuario"""
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='employee')  # admin, employee
    sucursal_id = db.Column(db.String(36), db.ForeignKey('sucursales.id'), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sucursal = db.relationship('Sucursal', backref='users')
    ventas = db.relationship('Venta', backref='cajero')
    
    def set_password(self, password):
        """Hashear contraseña"""
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def check_password(self, password):
        """Verificar contraseña"""
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'sucursal_id': self.sucursal_id,
            'sucursal_nombre': self.sucursal.nombre if self.sucursal else None,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat()
        }

class Sucursal(db.Model):
    """Modelo de sucursal"""
    __tablename__ = 'sucursales'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    nombre = db.Column(db.String(120), nullable=False, unique=True)
    direccion = db.Column(db.String(255), nullable=False)
    telefono = db.Column(db.String(20), nullable=True)
    ciudad = db.Column(db.String(100), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    stocks = db.relationship('Stock', backref='sucursal', cascade='all, delete-orphan')
    ventas = db.relationship('Venta', backref='sucursal')
    entradas_inventario = db.relationship('EntradaInventario', backref='sucursal')
    
    def to_dict(self):
        return {
            'id': self.id,
            'nombre': self.nombre,
            'direccion': self.direccion,
            'telefono': self.telefono,
            'ciudad': self.ciudad,
            'is_active': self.is_active
        }

class Categoria(db.Model):
    """Modelo de categoría de productos"""
    __tablename__ = 'categorias'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    nombre = db.Column(db.String(100), nullable=False, unique=True)
    descripcion = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    subcategorias = db.relationship('Subcategoria', backref='categoria', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'nombre': self.nombre,
            'descripcion': self.descripcion,
            'is_active': self.is_active
        }

class Subcategoria(db.Model):
    """Modelo de subcategoría de productos"""
    __tablename__ = 'subcategorias'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    nombre = db.Column(db.String(100), nullable=False)
    descripcion = db.Column(db.Text, nullable=True)
    categoria_id = db.Column(db.String(36), db.ForeignKey('categorias.id'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    productos = db.relationship('Producto', backref='subcategoria', cascade='all, delete-orphan')
    
    __table_args__ = (
        db.UniqueConstraint('nombre', 'categoria_id', name='uq_subcategoria_nombre_categoria'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'nombre': self.nombre,
            'descripcion': self.descripcion,
            'categoria_id': self.categoria_id,
            'is_active': self.is_active
        }

class Producto(db.Model):
    """Modelo de producto"""
    __tablename__ = 'productos'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    codigo = db.Column(db.String(50), unique=True, nullable=False, index=True)
    nombre = db.Column(db.String(255), nullable=False)
    descripcion = db.Column(db.Text, nullable=True)
    precio = db.Column(db.Numeric(10, 2), nullable=False)
    impuesto = db.Column(db.Numeric(5, 2), default=0)  # Porcentaje de impuesto
    subcategoria_id = db.Column(db.String(36), db.ForeignKey('subcategorias.id'), nullable=False)
    codigo_barras = db.Column(db.String(100), nullable=True, index=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    stocks = db.relationship('Stock', backref='producto', cascade='all, delete-orphan')
    detalles_venta = db.relationship('DetalleVenta', backref='producto')
    entradas_inventario = db.relationship('EntradaInventario', backref='producto')
    
    def to_dict(self, include_stock=False):
        data = {
            'id': self.id,
            'codigo': self.codigo,
            'nombre': self.nombre,
            'descripcion': self.descripcion,
            'precio': float(self.precio),
            'impuesto': float(self.impuesto),
            'subcategoria_id': self.subcategoria_id,
            'codigo_barras': self.codigo_barras,
            'is_active': self.is_active
        }
        if include_stock:
            data['stocks'] = [stock.to_dict() for stock in self.stocks]
        return data

class Stock(db.Model):
    """Modelo de stock de producto por sucursal"""
    __tablename__ = 'stocks'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    producto_id = db.Column(db.String(36), db.ForeignKey('productos.id'), nullable=False)
    sucursal_id = db.Column(db.String(36), db.ForeignKey('sucursales.id'), nullable=False)
    cantidad = db.Column(db.Integer, default=0)
    cantidad_minima = db.Column(db.Integer, default=5)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        db.UniqueConstraint('producto_id', 'sucursal_id', name='uq_stock_producto_sucursal'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'producto_id': self.producto_id,
            'sucursal_id': self.sucursal_id,
            'cantidad': self.cantidad,
            'cantidad_minima': self.cantidad_minima
        }

class EntradaInventario(db.Model):
    """Modelo para registrar entradas de inventario (compras a proveedores)"""
    __tablename__ = 'entradas_inventario'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    producto_id = db.Column(db.String(36), db.ForeignKey('productos.id'), nullable=False)
    sucursal_id = db.Column(db.String(36), db.ForeignKey('sucursales.id'), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False)
    numero_entrada = db.Column(db.String(50), unique=True, nullable=False)
    observaciones = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'producto_id': self.producto_id,
            'producto_nombre': self.producto.nombre,
            'sucursal_id': self.sucursal_id,
            'cantidad': self.cantidad,
            'numero_entrada': self.numero_entrada,
            'observaciones': self.observaciones,
            'created_at': self.created_at.isoformat()
        }

class Venta(db.Model):
    """Modelo de venta"""
    __tablename__ = 'ventas'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    numero_venta = db.Column(db.String(50), unique=True, nullable=False)
    sucursal_id = db.Column(db.String(36), db.ForeignKey('sucursales.id'), nullable=False)
    cajero_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    total = db.Column(db.Numeric(10, 2), nullable=False)
    total_impuestos = db.Column(db.Numeric(10, 2), default=0)
    forma_pago = db.Column(db.String(50), nullable=False)  # efectivo, tarjeta, transferencia, etc
    observaciones = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    detalles = db.relationship('DetalleVenta', backref='venta', cascade='all, delete-orphan')
    
    def to_dict(self, include_detalles=False):
        data = {
            'id': self.id,
            'numero_venta': self.numero_venta,
            'sucursal_id': self.sucursal_id,
            'sucursal_nombre': self.sucursal.nombre,
            'cajero_id': self.cajero_id,
            'cajero_nombre': self.cajero.username,
            'total': float(self.total),
            'total_impuestos': float(self.total_impuestos),
            'forma_pago': self.forma_pago,
            'observaciones': self.observaciones,
            'created_at': self.created_at.isoformat()
        }
        if include_detalles:
            data['detalles'] = [detalle.to_dict() for detalle in self.detalles]
        return data

class DetalleVenta(db.Model):
    """Modelo de detalle de venta (productos en una venta)"""
    __tablename__ = 'detalles_venta'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    venta_id = db.Column(db.String(36), db.ForeignKey('ventas.id'), nullable=False)
    producto_id = db.Column(db.String(36), db.ForeignKey('productos.id'), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False)
    precio_unitario = db.Column(db.Numeric(10, 2), nullable=False)
    impuesto_unitario = db.Column(db.Numeric(5, 2), default=0)
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'venta_id': self.venta_id,
            'producto_id': self.producto_id,
            'producto_nombre': self.producto.nombre,
            'cantidad': self.cantidad,
            'precio_unitario': float(self.precio_unitario),
            'impuesto_unitario': float(self.impuesto_unitario),
            'subtotal': float(self.subtotal)
        }
