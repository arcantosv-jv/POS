const { createApp, ref, reactive, computed, watch } = Vue;

// ============= COMPONENTE: VENTAS (Punto de Venta) =============
const VentasView = {
    props: ['apiUrl', 'token', 'userSucursal', 'userRole'],
    template: `
        <div class="grid grid-2" style="gap: 2rem;">
            <div>
                <div class="card">
                    <div class="card-header">
                        <h3>Buscar Productos</h3>
                    </div>
                    
                    <div class="search-box" style="position: relative;">
                        <input 
                            v-model="searchQuery"
                            type="text"
                            placeholder="Escribe nombre, código o barras... (mín. 1 caracter)"
                            @input="buscarProductos"
                            style="width: 100%; padding: 0.75rem; border: 1px solid var(--gray-300); border-radius: 0.375rem;"
                        >
                        
                        <div v-if="searchResults.length > 0" class="search-results">
                            <div 
                                v-for="producto in searchResults" 
                                :key="producto.id"
                                class="search-result-item"
                                @click="agregarAlCarrito(producto)"
                            >
                                <div class="search-result-name">{{ producto.nombre }}</div>
                                <div class="search-result-code">Código: {{ producto.codigo }}</div>
                                <div class="search-result-price">💵 ${{ producto.precio }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3>Productos Recientes</h3>
                    </div>
                    
                    <div v-if="loading" style="text-align: center; padding: 1rem;">
                        <span class="spinner"></span>
                    </div>
                    
                    <div v-else-if="productos.length === 0" style="padding: 1rem; text-align: center; color: var(--gray-600);">
                        No hay productos disponibles
                    </div>
                    
                    <div v-else style="max-height: 600px; overflow-y: auto;">
                        <div 
                            v-for="producto in productos.slice(0, 20)" 
                            :key="producto.id"
                            style="padding: 0.75rem; border-bottom: 1px solid var(--gray-200); cursor: pointer; transition: background-color 0.2s;"
                            @click="agregarAlCarrito(producto)"
                            @mouseover="$event.target.style.backgroundColor = 'var(--gray-100)'"
                            @mouseout="$event.target.style.backgroundColor = 'transparent'"
                        >
                            <div style="font-weight: 600; margin-bottom: 0.25rem;">{{ producto.nombre }}</div>
                            <div style="font-size: 0.875rem; color: var(--gray-600);">{{ producto.codigo }}</div>
                            <div style="font-weight: 500; color: var(--primary);">💵 ${{ producto.precio }}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div class="card" style="position: sticky; top: 80px;">
                    <div class="card-header">
                        <h3>🛒 Carrito</h3>
                        <button v-if="carrito.length > 0" @click="limpiarCarrito" class="btn btn-secondary btn-sm">Limpiar</button>
                    </div>
                    
                    <div v-if="carrito.length === 0" style="padding: 2rem; text-align: center; color: var(--gray-600);">
                        Carrito vacío
                    </div>

                    <div v-else style="max-height: 400px; overflow-y: auto; margin-bottom: 1rem;">
                        <div v-for="(item, index) in carrito" :key="index" class="cart-item">
                            <div class="cart-item-info">
                                <div class="cart-item-name">{{ item.nombre }}</div>
                                <div class="cart-item-price">\${{ item.precio }} c/u</div>
                            </div>
                            <div class="cart-item-qty">
                                <button @click="decrementarCantidad(index)">−</button>
                                <input v-model.number="item.cantidad" type="number" min="1" @change="actualizarCarrito">
                                <button @click="incrementarCantidad(index)">+</button>
                            </div>
                            <div style="font-weight: 600; min-width: 70px; text-align: right;">
                                \${{ (item.cantidad * item.precio).toFixed(2) }}
                            </div>
                            <button @click="removerDelCarrito(index)" class="btn btn-danger btn-sm">🗑</button>
                        </div>
                    </div>

                    <div class="cart-summary">
                        <div class="summary-row">
                            <span>Subtotal:</span>
                            <span>\${{ subtotal.toFixed(2) }}</span>
                        </div>
                        <div class="summary-row">
                            <span>Impuestos:</span>
                            <span>\${{ totalImpuestos.toFixed(2) }}</span>
                        </div>
                        <div class="summary-row total">
                            <span>TOTAL:</span>
                            <span>\${{ total.toFixed(2) }}</span>
                        </div>

                        <div class="form-group" style="margin-top: 1rem;">
                            <label>Forma de Pago</label>
                            <select v-model="formaPago" style="width: 100%; padding: 0.5rem;">
                                <option value="efectivo">💵 Efectivo</option>
                                <option value="tarjeta">💳 Tarjeta</option>
                                <option value="transferencia">🏦 Transferencia</option>
                                <option value="mixto">🔀 Mixto</option>
                            </select>
                        </div>

                        <button 
                            v-if="carrito.length > 0"
                            @click="registrarVenta"
                            class="btn btn-success"
                            style="width: 100%; margin-top: 1rem;"
                            :disabled="procesandoVenta"
                        >
                            <span v-if="!procesandoVenta">✓ Cobrar \${{ total.toFixed(2) }}</span>
                            <span v-else><span class="spinner"></span> Procesando...</span>
                        </button>
                    </div>
                </div>

                <div v-if="ventaExitosa" class="alert alert-success" style="margin-top: 1rem;">
                    ✓ Venta registrada: {{ ventaExitosa }}
                    <button @click="imprimirTicket" class="btn btn-primary btn-sm" style="margin-top: 0.5rem; width: 100%;">
                        🖨 Imprimir Ticket
                    </button>
                </div>

                <div v-if="error" class="alert alert-danger" style="margin-top: 1rem;">
                    {{ error }}
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            carrito: [],
            productos: [],
            searchQuery: '',
            searchResults: [],
            formaPago: 'efectivo',
            loading: true,
            procesandoVenta: false,
            error: '',
            ventaExitosa: '',
            ultimaVentaId: ''
        };
    },
    computed: {
        subtotal() {
            return this.carrito.reduce((sum, item) => sum + (item.cantidad * item.precio), 0);
        },
        totalImpuestos() {
            return this.carrito.reduce((sum, item) => {
                const impuesto = item.impuesto || 0;
                return sum + (item.cantidad * item.precio * impuesto / 100);
            }, 0);
        },
        total() {
            return this.subtotal + this.totalImpuestos;
        }
    },
    methods: {
        async cargarProductos() {
            try {
                const response = await axios.get(
                    `${this.apiUrl}/api/productos`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.productos = response.data.productos || [];
            } catch (err) {
                this.error = 'Error cargando productos';
                console.error(err);
            } finally {
                this.loading = false;
            }
        },
        async buscarProductos() {
            if (this.searchQuery.length < 1) {
                this.searchResults = [];
                return;
            }
            
            try {
                const response = await axios.get(
                    `${this.apiUrl}/api/productos/buscar`,
                    {
                        params: { 
                            q: this.searchQuery,
                            sucursal_id: this.userSucursal
                        },
                        headers: { Authorization: `Bearer ${this.token}` }
                    }
                );
                this.searchResults = response.data;
            } catch (err) {
                console.error(err);
            }
        },
        agregarAlCarrito(producto) {
            const existe = this.carrito.find(item => item.id === producto.id);
            if (existe) {
                existe.cantidad++;
            } else {
                this.carrito.push({
                    id: producto.id,
                    nombre: producto.nombre,
                    codigo: producto.codigo,
                    precio: parseFloat(producto.precio),
                    impuesto: parseFloat(producto.impuesto || 0),
                    cantidad: 1
                });
            }
            this.searchQuery = '';
            this.searchResults = [];
            this.error = '';
        },
        removerDelCarrito(index) {
            this.carrito.splice(index, 1);
        },
        incrementarCantidad(index) {
            this.carrito[index].cantidad++;
        },
        decrementarCantidad(index) {
            if (this.carrito[index].cantidad > 1) {
                this.carrito[index].cantidad--;
            }
        },
        actualizarCarrito() {
            // Se actualiza automáticamente
        },
        limpiarCarrito() {
            this.carrito = [];
            this.error = '';
            this.ventaExitosa = '';
        },
        async registrarVenta() {
            if (this.carrito.length === 0) return;
            
            this.procesandoVenta = true;
            this.error = '';
            
            try {
                const detalles = this.carrito.map(item => ({
                    producto_id: item.id,
                    cantidad: item.cantidad
                }));

                const response = await axios.post(
                    `${this.apiUrl}/api/ventas`,
                    {
                        detalles,
                        forma_pago: this.formaPago
                    },
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );

                this.ultimaVentaId = response.data.venta.id;
                this.ventaExitosa = response.data.venta.numero_venta;
                this.carrito = [];
                this.formaPago = 'efectivo';
            } catch (err) {
                this.error = err.response?.data?.error || 'Error registrando venta';
            } finally {
                this.procesandoVenta = false;
            }
        },
        async imprimirTicket() {
            try {
                const response = await axios.get(
                    `${this.apiUrl}/api/ventas/${this.ultimaVentaId}/ticket`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                
                const ticket = response.data;
                const contenido = this.generarHTMLTicket(ticket);
                
                const ventana = window.open('', '', 'width=400,height=600');
                ventana.document.write(contenido);
                ventana.document.close();
                ventana.print();
            } catch (err) {
                alert('Error generando ticket');
            }
        },
        generarHTMLTicket(ticket) {
            let html = `
                <html>
                <head>
                    <style>
                        body { font-family: monospace; font-size: 12px; padding: 10px; }
                        h1 { text-align: center; font-size: 18px; }
                        .separator { border-bottom: 1px dashed #000; margin: 10px 0; }
                        .item { display: flex; justify-content: space-between; }
                        .total { font-weight: bold; font-size: 14px; }
                    </style>
                </head>
                <body>
                    <h1>TICKET</h1>
                    <p><strong>Venta:</strong> ${ticket.numero_venta}</p>
                    <p><strong>Sucursal:</strong> ${ticket.sucursal}</p>
                    <p><strong>Dirección:</strong> ${ticket.direccion}</p>
                    <p><strong>Fecha:</strong> ${ticket.fecha}</p>
                    <p><strong>Cajero:</strong> ${ticket.cajero}</p>
                    <div class="separator"></div>
                    <h3>Productos</h3>
            `;
            
            ticket.detalles.forEach(detalle => {
                html += `
                    <div class="item">
                        <span>${detalle.producto}</span>
                        <span>${detalle.cantidad}x</span>
                        <span>$${detalle.subtotal.toFixed(2)}</span>
                    </div>
                `;
            });
            
            html += `
                    <div class="separator"></div>
                    <div class="item">
                        <span>SUBTOTAL:</span>
                        <span>$${ticket.subtotal.toFixed(2)}</span>
                    </div>
                    <div class="item">
                        <span>IMPUESTOS:</span>
                        <span>$${ticket.total_impuestos.toFixed(2)}</span>
                    </div>
                    <div class="item total" style="font-size: 16px; margin-top: 10px;">
                        <span>TOTAL:</span>
                        <span>$${ticket.total.toFixed(2)}</span>
                    </div>
                    <p style="text-align: center; margin-top: 20px;">Forma de Pago: ${ticket.forma_pago.toUpperCase()}</p>
                    <p style="text-align: center;">Gracias por su compra</p>
                </body>
                </html>
            `;
            return html;
        }
    },
    mounted() {
        this.cargarProductos();
    }
};

// ============= COMPONENTE: PRODUCTOS (Admin) =============
const ProductosView = {
    props: ['apiUrl', 'token'],
    template: `
        <div>
            <div class="card">
                <div class="card-header">
                    <h3>Gestión de Productos</h3>
                    <div class="btn-group">
                        <button @click="mostrarFormulario = !mostrarFormulario" class="btn btn-primary">
                            {{ mostrarFormulario ? '← Ocultar' : '+ Nuevo Producto' }}
                        </button>
                        <button @click="mostrarImportacion = !mostrarImportacion" class="btn btn-success">
                            📤 Importar Excel/CSV
                        </button>
                    </div>
                </div>

                <!-- Formulario de nuevo producto -->
                <div v-if="mostrarFormulario" style="background-color: var(--gray-50); padding: 1.5rem; border-radius: 0.375rem; margin-bottom: 1.5rem;">
                    <h4 style="margin-bottom: 1rem;">Nuevo Producto</h4>
                    <div class="grid grid-3">
                        <div class="form-group">
                            <label>Código</label>
                            <input v-model="nuevoProducto.codigo" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>Nombre</label>
                            <input v-model="nuevoProducto.nombre" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>Precio</label>
                            <input v-model.number="nuevoProducto.precio" type="number" step="0.01" required>
                        </div>
                    </div>
                    <div class="grid grid-3">
                        <div class="form-group">
                            <label>Impuesto (%)</label>
                            <input v-model.number="nuevoProducto.impuesto" type="number" step="0.01" min="0">
                        </div>
                        <div class="form-group">
                            <label>Código de Barras</label>
                            <input v-model="nuevoProducto.codigo_barras" type="text">
                        </div>
                        <div class="form-group">
                            <label>Subcategoría</label>
                            <select v-model="nuevoProducto.subcategoria_id" required>
                                <option value="">Selecciona subcategoría</option>
                                <option v-for="sub in subcategorias" :key="sub.id" :value="sub.id">
                                    {{ sub.nombre }}
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea v-model="nuevoProducto.descripcion" rows="3"></textarea>
                    </div>
                    <div class="btn-group">
                        <button @click="guardarProducto" class="btn btn-success">Guardar Producto</button>
                        <button @click="mostrarFormulario = false" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>

                <!-- Importación de CSV/Excel -->
                <div v-if="mostrarImportacion" style="background-color: var(--gray-50); padding: 1.5rem; border-radius: 0.375rem; margin-bottom: 1.5rem;">
                    <h4 style="margin-bottom: 1rem;">Importar Productos desde CSV/Excel</h4>
                    <p style="margin-bottom: 1rem; color: var(--gray-600);">
                        Carga un archivo CSV con las siguientes columnas: Handle, REF, Nombre, Categoria, Precio [Sucursal], En inventario [Sucursal]
                    </p>
                    <div class="form-group">
                        <label>Archivo CSV/Excel</label>
                        <input 
                            type="file" 
                            accept=".csv,.xlsx"
                            @change="manejarCargaArchivo"
                            style="width: 100%; padding: 0.5rem; border: 2px dashed var(--primary); border-radius: 0.375rem;"
                        >
                    </div>
                    <div v-if="archivoSeleccionado" style="margin-bottom: 1rem;">
                        <p>📄 {{ archivoSeleccionado.name }}</p>
                        <div class="form-group">
                            <label>Sucursal para el stock</label>
                            <select v-model="sucursalImportacion" required>
                                <option value="">Selecciona sucursal</option>
                                <option v-for="suc in sucursales" :key="suc.id" :value="suc.id">
                                    {{ suc.nombre }}
                                </option>
                            </select>
                        </div>
                        <button @click="procesarImportacion" class="btn btn-success" :disabled="importandoProductos">
                            <span v-if="!importandoProductos">✓ Importar Productos</span>
                            <span v-else><span class="spinner"></span> Procesando...</span>
                        </button>
                    </div>
                    <div v-if="mensajeImportacion" :class="['alert', 'alert-' + tipoMensajeImportacion]">
                        {{ mensajeImportacion }}
                    </div>
                </div>

                <!-- Búsqueda y filtros -->
                <div style="margin-bottom: 1rem;">
                    <input 
                        v-model="busquedaProducto"
                        type="text"
                        placeholder="Buscar productos..."
                        style="width: 100%; padding: 0.75rem; border: 1px solid var(--gray-300); border-radius: 0.375rem;"
                    >
                </div>

                <!-- Tabla de productos -->
                <div v-if="loading" style="text-align: center; padding: 2rem;">
                    <span class="spinner"></span>
                </div>
                <div v-else-if="productosFiltrados.length === 0" style="padding: 2rem; text-align: center; color: var(--gray-600);">
                    No hay productos
                </div>
                <div v-else style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Nombre</th>
                                <th>Precio</th>
                                <th>Impuesto</th>
                                <th>Categoría</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="producto in productosFiltrados" :key="producto.id">
                                <td>{{ producto.codigo }}</td>
                                <td>{{ producto.nombre }}</td>
                                <td>${{ producto.precio }}</td>
                                <td>{{ producto.impuesto }}%</td>
                                <td>{{ producto.subcategoria_id }}</td>
                                <td>
                                    <button class="btn btn-primary btn-sm" @click="editarProducto(producto)">Editar</button>
                                    <button class="btn btn-danger btn-sm" @click="eliminarProducto(producto.id)">Eliminar</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            productos: [],
            subcategorias: [],
            sucursales: [],
            mostrarFormulario: false,
            mostrarImportacion: false,
            loading: true,
            busquedaProducto: '',
            nuevoProducto: {
                codigo: '',
                nombre: '',
                precio: 0,
                impuesto: 0,
                codigo_barras: '',
                subcategoria_id: '',
                descripcion: ''
            },
            archivoSeleccionado: null,
            sucursalImportacion: '',
            importandoProductos: false,
            mensajeImportacion: '',
            tipoMensajeImportacion: 'success'
        };
    },
    computed: {
        productosFiltrados() {
            return this.productos.filter(p => 
                p.nombre.toLowerCase().includes(this.busquedaProducto.toLowerCase()) ||
                p.codigo.toLowerCase().includes(this.busquedaProducto.toLowerCase())
            );
        }
    },
    methods: {
        async cargarProductos() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/productos`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.productos = res.data.productos || [];
            } catch (err) {
                console.error(err);
            } finally {
                this.loading = false;
            }
        },
        async cargarSubcategorias() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/productos/subcategorias`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.subcategorias = res.data;
            } catch (err) {
                console.error(err);
            }
        },
        async cargarSucursales() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/admin/sucursales`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.sucursales = res.data;
            } catch (err) {
                console.error(err);
            }
        },
        async guardarProducto() {
            try {
                await axios.post(
                    `${this.apiUrl}/api/productos`,
                    this.nuevoProducto,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.mostrarFormulario = false;
                this.nuevoProducto = { codigo: '', nombre: '', precio: 0, impuesto: 0, codigo_barras: '', subcategoria_id: '', descripcion: '' };
                await this.cargarProductos();
            } catch (err) {
                alert('Error guardando producto: ' + err.response?.data?.error);
            }
        },
        manejarCargaArchivo(evento) {
            this.archivoSeleccionado = evento.target.files[0];
            this.mensajeImportacion = '';
        },
        async procesarImportacion() {
            if (!this.archivoSeleccionado || !this.sucursalImportacion) {
                alert('Selecciona archivo y sucursal');
                return;
            }

            this.importandoProductos = true;
            this.mensajeImportacion = '';
            
            try {
                const reader = new FileReader();
                reader.onload = async (e) => {
                    try {
                        const csv = e.target.result;
                        const lineas = csv.split('\n');
                        const encabezados = lineas[0].split(',').map(h => h.trim());
                        
                        // Encontrar índices de columnas
                        const idxCodigo = encabezados.findIndex(h => h === 'REF');
                        const idxNombre = encabezados.findIndex(h => h === 'Nombre');
                        const idxCategoria = encabezados.findIndex(h => h === 'Categoria');
                        
                        // Buscar columna de precio para la sucursal
                        const columnaSucursal = encabezados.find(h => h.includes('Precio ['));
                        const idxPrecio = columnaSucursal ? encabezados.indexOf(columnaSucursal) : -1;
                        
                        // Buscar columna de stock para la sucursal
                        const columnaStock = encabezados.find(h => h.includes('En inventario ['));
                        const idxStock = columnaStock ? encabezados.indexOf(columnaStock) : -1;
                        
                        const productosProcesados = [];
                        const errores = [];
                        
                        for (let i = 1; i < lineas.length; i++) {
                            const linea = lineas[i].trim();
                            if (!linea) continue;
                            
                            const valores = linea.split(',').map(v => v.trim().replace(/"/g, ''));
                            
                            const codigo = valores[idxCodigo]?.trim();
                            const nombre = valores[idxNombre]?.trim();
                            const categoria = valores[idxCategoria]?.trim();
                            const precio = parseFloat(valores[idxPrecio]) || 0;
                            const stock = parseInt(valores[idxStock]) || 0;
                            
                            if (codigo && nombre) {
                                productosProcesados.push({
                                    codigo,
                                    nombre,
                                    categoria,
                                    precio,
                                    stock,
                                    sucursal_id: this.sucursalImportacion
                                });
                            }
                        }
                        
                        // Enviar productos procesados al servidor
                        const response = await axios.post(
                            `${this.apiUrl}/api/productos/importar`,
                            { productos: productosProcesados },
                            { headers: { Authorization: `Bearer ${this.token}` } }
                        );
                        
                        this.mensajeImportacion = `✓ ${response.data.importados} productos importados exitosamente`;
                        this.tipoMensajeImportacion = 'success';
                        this.archivoSeleccionado = null;
                        await this.cargarProductos();
                    } catch (err) {
                        this.mensajeImportacion = 'Error procesando archivo: ' + (err.response?.data?.error || err.message);
                        this.tipoMensajeImportacion = 'danger';
                    } finally {
                        this.importandoProductos = false;
                    }
                };
                reader.readAsText(this.archivoSeleccionado);
            } catch (err) {
                this.mensajeImportacion = 'Error: ' + err.message;
                this.tipoMensajeImportacion = 'danger';
                this.importandoProductos = false;
            }
        },
        editarProducto(producto) {
            console.log('Editar:', producto);
        },
        async eliminarProducto(id) {
            if (!confirm('¿Eliminar producto?')) return;
            try {
                await axios.delete(
                    `${this.apiUrl}/api/productos/${id}`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                await this.cargarProductos();
            } catch (err) {
                alert('Error: ' + err.response?.data?.error);
            }
        }
    },
    mounted() {
        this.cargarProductos();
        this.cargarSubcategorias();
        this.cargarSucursales();
    }
};

// ============= COMPONENTE: INVENTARIO (Admin) =============
const InventarioView = {
    props: ['apiUrl', 'token', 'userRole'],
    template: `
        <div>
            <div class="card">
                <div class="card-header">
                    <h3>Gestión de Inventario</h3>
                    <button @click="mostrarEntrada = !mostrarEntrada" class="btn btn-primary">
                        {{ mostrarEntrada ? '← Ocultar' : '+ Registrar Entrada' }}
                    </button>
                </div>

                <!-- Formulario de entrada -->
                <div v-if="mostrarEntrada" style="background-color: var(--gray-50); padding: 1.5rem; border-radius: 0.375rem; margin-bottom: 1.5rem;">
                    <h4 style="margin-bottom: 1rem;">Registrar Entrada de Inventario</h4>
                    <div class="grid grid-3">
                        <div class="form-group">
                            <label>Sucursal</label>
                            <select v-model="entrada.sucursal_id" required>
                                <option value="">Selecciona sucursal</option>
                                <option v-for="suc in sucursales" :key="suc.id" :value="suc.id">
                                    {{ suc.nombre }}
                                </option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Producto</label>
                            <input 
                                v-model="busquedaProductoEntrada"
                                type="text"
                                placeholder="Busca producto..."
                                style="width: 100%; padding: 0.5rem;"
                            >
                            <div v-if="productosEncontrados.length > 0" style="position: absolute; background: white; border: 1px solid var(--gray-300); border-radius: 0.375rem; width: 100%; max-height: 200px; overflow-y: auto; z-index: 10;">
                                <div 
                                    v-for="prod in productosEncontrados" 
                                    :key="prod.id"
                                    @click="entrada.producto_id = prod.id; busquedaProductoEntrada = prod.nombre;"
                                    style="padding: 0.5rem; cursor: pointer; border-bottom: 1px solid var(--gray-200);"
                                >
                                    {{ prod.nombre }} ({{ prod.codigo }})
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Cantidad</label>
                            <input v-model.number="entrada.cantidad" type="number" min="1" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Observaciones</label>
                        <textarea v-model="entrada.observaciones" rows="2"></textarea>
                    </div>
                    <div class="btn-group">
                        <button @click="registrarEntrada" class="btn btn-success">Registrar Entrada</button>
                        <button @click="mostrarEntrada = false" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>

                <div v-if="mensajeEntrada" :class="['alert', 'alert-' + tipoMensajeEntrada]">
                    {{ mensajeEntrada }}
                </div>

                <!-- Tabla de stock por sucursal -->
                <h4 style="margin-bottom: 1rem; margin-top: 2rem;">Stock Actual por Sucursal</h4>
                <div class="form-group">
                    <label>Selecciona Sucursal</label>
                    <select v-model="sucursalSeleccionada" @change="cargarStock">
                        <option value="">Todas</option>
                        <option v-for="suc in sucursales" :key="suc.id" :value="suc.id">
                            {{ suc.nombre }}
                        </option>
                    </select>
                </div>

                <div v-if="cargandoStock" style="text-align: center; padding: 2rem;">
                    <span class="spinner"></span>
                </div>
                <div v-else-if="stocks.length === 0" style="padding: 2rem; text-align: center; color: var(--gray-600);">
                    No hay productos en stock
                </div>
                <div v-else style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Producto</th>
                                <th>Cantidad</th>
                                <th>Mínimo</th>
                                <th>Estado</th>
                                <th>Precio</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="stock in stocks" :key="stock.id">
                                <td>{{ stock.producto_codigo }}</td>
                                <td>{{ stock.producto_nombre }}</td>
                                <td style="font-weight: 600;">{{ stock.cantidad }}</td>
                                <td>{{ stock.cantidad_minima }}</td>
                                <td>
                                    <span v-if="stock.cantidad <= stock.cantidad_minima" style="color: var(--danger); font-weight: 600;">
                                        ⚠ Bajo Stock
                                    </span>
                                    <span v-else style="color: var(--success);">✓ OK</span>
                                </td>
                                <td>\${{ stock.precio }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            sucursales: [],
            stocks: [],
            productos: [],
            mostrarEntrada: false,
            sucursalSeleccionada: '',
            cargandoStock: false,
            entrada: {
                sucursal_id: '',
                producto_id: '',
                cantidad: 1,
                observaciones: ''
            },
            busquedaProductoEntrada: '',
            mensajeEntrada: '',
            tipoMensajeEntrada: 'success'
        };
    },
    computed: {
        productosEncontrados() {
            if (!this.busquedaProductoEntrada) return [];
            return this.productos.filter(p => 
                p.nombre.toLowerCase().includes(this.busquedaProductoEntrada.toLowerCase()) ||
                p.codigo.toLowerCase().includes(this.busquedaProductoEntrada.toLowerCase())
            ).slice(0, 5);
        }
    },
    methods: {
        async cargarSucursales() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/admin/sucursales`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.sucursales = res.data;
                if (this.sucursales.length > 0) {
                    this.sucursalSeleccionada = this.sucursales[0].id;
                }
            } catch (err) {
                console.error(err);
            }
        },
        async cargarStock() {
            this.cargandoStock = true;
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/inventario/stock/${this.sucursalSeleccionada}`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.stocks = res.data.stocks;
            } catch (err) {
                console.error(err);
            } finally {
                this.cargandoStock = false;
            }
        },
        async cargarProductos() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/productos?per_page=2000`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.productos = res.data.productos || [];
            } catch (err) {
                console.error(err);
            }
        },
        async registrarEntrada() {
            if (!this.entrada.sucursal_id || !this.entrada.producto_id || this.entrada.cantidad <= 0) {
                this.mensajeEntrada = 'Completa todos los campos requeridos';
                this.tipoMensajeEntrada = 'danger';
                return;
            }

            try {
                const res = await axios.post(
                    `${this.apiUrl}/api/inventario/entrada`,
                    this.entrada,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                
                this.mensajeEntrada = `✓ Entrada registrada. Nuevo stock: ${res.data.nuevo_stock}`;
                this.tipoMensajeEntrada = 'success';
                this.mostrarEntrada = false;
                this.entrada = { sucursal_id: '', producto_id: '', cantidad: 1, observaciones: '' };
                this.busquedaProductoEntrada = '';
                await this.cargarStock();
            } catch (err) {
                this.mensajeEntrada = 'Error: ' + (err.response?.data?.error || err.message);
                this.tipoMensajeEntrada = 'danger';
            }
        }
    },
    mounted() {
        this.cargarSucursales();
        this.cargarProductos();
    },
    watch: {
        sucursalSeleccionada() {
            if (this.sucursalSeleccionada) {
                this.cargarStock();
            }
        }
    }
};

// ============= COMPONENTE: REPORTES (Admin) =============
const ReportesView = {
    props: ['apiUrl', 'token'],
    template: `
        <div>
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Ventas Hoy</h3>
                    <div class="value">\${{ ventasHoy }}</div>
                </div>
                <div class="stat-card">
                    <h3>Transacciones</h3>
                    <div class="value">{{ transaccionesHoy }}</div>
                </div>
                <div class="stat-card">
                    <h3>Promedio</h3>
                    <div class="value">\${{ promedioVenta }}</div>
                </div>
                <div class="stat-card">
                    <h3>Impuestos</h3>
                    <div class="value">\${{ impuestosHoy }}</div>
                </div>
            </div>

            <div class="grid grid-2" style="gap: 2rem;">
                <div class="card">
                    <div class="card-header">
                        <h3>Reporte Diario</h3>
                    </div>
                    <div class="form-group">
                        <label>Fecha</label>
                        <input v-model="fechaReporte" type="date">
                    </div>
                    <div class="form-group">
                        <label>Sucursal</label>
                        <select v-model="sucursalReporte">
                            <option value="">Todas</option>
                            <option v-for="suc in sucursales" :key="suc.id" :value="suc.id">
                                {{ suc.nombre }}
                            </option>
                        </select>
                    </div>
                    <button @click="generarReporteDiario" class="btn btn-primary" style="width: 100%;">
                        Generar Reporte
                    </button>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3>Reporte Mensual</h3>
                    </div>
                    <div class="form-group">
                        <label>Mes</label>
                        <input v-model="mesReporte" type="month">
                    </div>
                    <div class="form-group">
                        <label>Sucursal</label>
                        <select v-model="sucursalReporte">
                            <option value="">Todas</option>
                            <option v-for="suc in sucursales" :key="suc.id" :value="suc.id">
                                {{ suc.nombre }}
                            </option>
                        </select>
                    </div>
                    <button @click="generarReporteMensual" class="btn btn-primary" style="width: 100%;">
                        Generar Reporte
                    </button>
                </div>
            </div>

            <div v-if="reporteActual" class="card" style="margin-top: 2rem;">
                <div class="card-header">
                    <h3>Resultados del Reporte</h3>
                </div>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Concepto</th>
                                <th>Valor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Total de Ventas</td>
                                <td>\${{ reporteActual.total_ventas?.toFixed(2) }}</td>
                            </tr>
                            <tr>
                                <td>Total de Impuestos</td>
                                <td>\${{ reporteActual.total_impuestos?.toFixed(2) }}</td>
                            </tr>
                            <tr>
                                <td>Cantidad de Transacciones</td>
                                <td>{{ reporteActual.cantidad_transacciones }}</td>
                            </tr>
                            <tr>
                                <td>Promedio por Venta</td>
                                <td>\${{ reporteActual.promedio_venta?.toFixed(2) }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            sucursales: [],
            ventasHoy: 0,
            transaccionesHoy: 0,
            promedioVenta: 0,
            impuestosHoy: 0,
            fechaReporte: new Date().toISOString().split('T')[0],
            mesReporte: new Date().toISOString().slice(0, 7),
            sucursalReporte: '',
            reporteActual: null
        };
    },
    methods: {
        async cargarSucursales() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/admin/sucursales`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.sucursales = res.data;
            } catch (err) {
                console.error(err);
            }
        },
        async cargarVentasHoy() {
            try {
                const hoy = new Date().toISOString().split('T')[0];
                const res = await axios.get(
                    `${this.apiUrl}/api/reportes/ventas-diarias`,
                    {
                        params: { fecha: hoy },
                        headers: { Authorization: `Bearer ${this.token}` }
                    }
                );
                this.ventasHoy = res.data.total_ventas.toFixed(2);
                this.transaccionesHoy = res.data.cantidad_transacciones;
                this.promedioVenta = res.data.promedio_venta?.toFixed(2);
                this.impuestosHoy = res.data.total_impuestos.toFixed(2);
            } catch (err) {
                console.error(err);
            }
        },
        async generarReporteDiario() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/reportes/ventas-diarias`,
                    {
                        params: {
                            fecha: this.fechaReporte,
                            sucursal_id: this.sucursalReporte || undefined
                        },
                        headers: { Authorization: `Bearer ${this.token}` }
                    }
                );
                this.reporteActual = res.data;
            } catch (err) {
                alert('Error generando reporte');
            }
        },
        async generarReporteMensual() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/reportes/ventas-mensuales`,
                    {
                        params: {
                            mes: this.mesReporte,
                            sucursal_id: this.sucursalReporte || undefined
                        },
                        headers: { Authorization: `Bearer ${this.token}` }
                    }
                );
                this.reporteActual = res.data;
            } catch (err) {
                alert('Error generando reporte');
            }
        }
    },
    mounted() {
        this.cargarSucursales();
        this.cargarVentasHoy();
    }
};

// ============= COMPONENTE: USUARIOS (Admin) =============
const UsuariosView = {
    props: ['apiUrl', 'token'],
    template: `
        <div>
            <div class="card">
                <div class="card-header">
                    <h3>Gestión de Usuarios</h3>
                    <button @click="mostrarFormulario = !mostrarFormulario" class="btn btn-primary">
                        {{ mostrarFormulario ? '← Ocultar' : '+ Nuevo Usuario' }}
                    </button>
                </div>

                <div v-if="mostrarFormulario" style="background-color: var(--gray-50); padding: 1.5rem; border-radius: 0.375rem; margin-bottom: 1.5rem;">
                    <h4 style="margin-bottom: 1rem;">Nuevo Usuario</h4>
                    <div class="grid grid-3">
                        <div class="form-group">
                            <label>Usuario</label>
                            <input v-model="nuevoUsuario.username" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input v-model="nuevoUsuario.email" type="email" required>
                        </div>
                        <div class="form-group">
                            <label>Contraseña</label>
                            <input v-model="nuevoUsuario.password" type="password" required>
                        </div>
                    </div>
                    <div class="grid grid-3">
                        <div class="form-group">
                            <label>Rol</label>
                            <select v-model="nuevoUsuario.role" required>
                                <option value="employee">Empleado</option>
                                <option value="admin">Administrador</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Sucursal</label>
                            <select v-model="nuevoUsuario.sucursal_id" v-if="nuevoUsuario.role === 'employee'" required>
                                <option value="">Selecciona sucursal</option>
                                <option v-for="suc in sucursales" :key="suc.id" :value="suc.id">
                                    {{ suc.nombre }}
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button @click="guardarUsuario" class="btn btn-success">Guardar Usuario</button>
                        <button @click="mostrarFormulario = false" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>

                <div v-if="loading" style="text-align: center; padding: 2rem;">
                    <span class="spinner"></span>
                </div>
                <div v-else-if="usuarios.length === 0" style="padding: 2rem; text-align: center; color: var(--gray-600);">
                    No hay usuarios
                </div>
                <div v-else style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Usuario</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Sucursal</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="usuario in usuarios" :key="usuario.id">
                                <td>{{ usuario.username }}</td>
                                <td>{{ usuario.email }}</td>
                                <td><strong>{{ usuario.role === 'admin' ? '🔑 Admin' : '👤 Empleado' }}</strong></td>
                                <td>{{ usuario.sucursal_nombre || '—' }}</td>
                                <td>{{ usuario.is_active ? '✓ Activo' : '✗ Inactivo' }}</td>
                                <td>
                                    <button class="btn btn-danger btn-sm" @click="desactivarUsuario(usuario.id)">Desactivar</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            usuarios: [],
            sucursales: [],
            mostrarFormulario: false,
            loading: true,
            nuevoUsuario: {
                username: '',
                email: '',
                password: '',
                role: 'employee',
                sucursal_id: ''
            }
        };
    },
    methods: {
        async cargarUsuarios() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/admin/usuarios`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.usuarios = res.data;
            } catch (err) {
                console.error(err);
            } finally {
                this.loading = false;
            }
        },
        async cargarSucursales() {
            try {
                const res = await axios.get(
                    `${this.apiUrl}/api/admin/sucursales`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.sucursales = res.data;
            } catch (err) {
                console.error(err);
            }
        },
        async guardarUsuario() {
            try {
                await axios.post(
                    `${this.apiUrl}/api/auth/register`,
                    this.nuevoUsuario,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.mostrarFormulario = false;
                this.nuevoUsuario = { username: '', email: '', password: '', role: 'employee', sucursal_id: '' };
                await this.cargarUsuarios();
            } catch (err) {
                alert('Error: ' + (err.response?.data?.error || err.message));
            }
        },
        async desactivarUsuario(id) {
            if (!confirm('¿Desactivar usuario?')) return;
            try {
                await axios.put(
                    `${this.apiUrl}/api/admin/usuarios/${id}`,
                    { is_active: false },
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                await this.cargarUsuarios();
            } catch (err) {
                alert('Error: ' + err.response?.data?.error);
            }
        }
    },
    mounted() {
        this.cargarUsuarios();
        this.cargarSucursales();
    }
};

// ============= COMPONENTE: DASHBOARD (Admin) =============
const DashboardView = {
    props: ['apiUrl', 'token'],
    template: `
        <div>
            <div class="stats-grid">
                <div class="stat-card" style="border-left-color: #10b981;">
                    <h3>Ventas Hoy</h3>
                    <div class="value">\${{ ventasHoy }}</div>
                </div>
                <div class="stat-card" style="border-left-color: #3b82f6;">
                    <h3>Transacciones</h3>
                    <div class="value">{{ transaccionesHoy }}</div>
                </div>
                <div class="stat-card" style="border-left-color: #f59e0b;">
                    <h3>Productos</h3>
                    <div class="value">{{ totalProductos }}</div>
                </div>
                <div class="stat-card" style="border-left-color: #ef4444;">
                    <h3>Bajo Stock</h3>
                    <div class="value">{{ bajoStock }}</div>
                </div>
            </div>

            <div class="grid grid-2" style="gap: 2rem; margin-top: 2rem;">
                <div class="card">
                    <div class="card-header">
                        <h3>Ventas por Sucursal (Hoy)</h3>
                    </div>
                    <div v-if="ventasPorSucursal.length === 0" style="padding: 1rem; text-align: center; color: var(--gray-600);">
                        Sin datos
                    </div>
                    <div v-else style="overflow-x: auto;">
                        <table>
                            <thead>
                                <tr>
                                    <th>Sucursal</th>
                                    <th>Total</th>
                                    <th>Transacciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="venta in ventasPorSucursal" :key="venta.sucursal_id">
                                    <td>{{ venta.sucursal }}</td>
                                    <td>\${{ venta.total.toFixed(2) }}</td>
                                    <td>{{ venta.cantidad }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3>Top 5 Productos Vendidos</h3>
                    </div>
                    <div v-if="productosTopVenta.length === 0" style="padding: 1rem; text-align: center; color: var(--gray-600);">
                        Sin datos
                    </div>
                    <div v-else>
                        <div v-for="prod in productosTopVenta" :key="prod.id" style="padding: 0.75rem; border-bottom: 1px solid var(--gray-200);">
                            <div style="font-weight: 600; margin-bottom: 0.25rem;">{{ prod.nombre }}</div>
                            <div style="font-size: 0.875rem; color: var(--gray-600);">
                                {{ prod.cantidad }} unidades | \${{ prod.ingresos.toFixed(2) }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            ventasHoy: 0,
            transaccionesHoy: 0,
            totalProductos: 0,
            bajoStock: 0,
            ventasPorSucursal: [],
            productosTopVenta: []
        };
    },
    methods: {
        async cargarDatos() {
            try {
                const hoy = new Date().toISOString().split('T')[0];
                
                // Ventas del día
                const resVentas = await axios.get(
                    `${this.apiUrl}/api/reportes/ventas-diarias`,
                    {
                        params: { fecha: hoy },
                        headers: { Authorization: `Bearer ${this.token}` }
                    }
                );
                this.ventasHoy = resVentas.data.total_ventas.toFixed(2);
                this.transaccionesHoy = resVentas.data.cantidad_transacciones;
                
                // Consolidado por sucursal
                const resConsolidado = await axios.get(
                    `${this.apiUrl}/api/reportes/consolidado-sucursales`,
                    {
                        params: { fecha_inicio: hoy },
                        headers: { Authorization: `Bearer ${this.token}` }
                    }
                );
                
                this.ventasPorSucursal = Object.values(resConsolidado.data.por_sucursal);
                
                // Productos vendidos
                const resProductos = await axios.get(
                    `${this.apiUrl}/api/reportes/productos-vendidos`,
                    { headers: { Authorization: `Bearer ${this.token}` } }
                );
                this.productosTopVenta = resProductos.data.slice(0, 5);
            } catch (err) {
                console.error(err);
            }
        }
    },
    mounted() {
        this.cargarDatos();
    }
};
