from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, Venta, DetalleVenta, Producto, Stock, Sucursal
from datetime import datetime
from decimal import Decimal
import uuid

ventas_bp = Blueprint('ventas', __name__, url_prefix='/api/ventas')

@ventas_bp.route('', methods=['POST'])
@jwt_required()
def crear_venta():
    """Crear nueva venta (carrito de compra)"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        # Solo empleados pueden crear ventas
        if user.role != 'employee':
            return jsonify({'error': 'Solo empleados pueden crear ventas'}), 403
        
        data = request.get_json()
        
        # Validaciones
        if not data.get('detalles') or len(data['detalles']) == 0:
            return jsonify({'error': 'La venta debe tener al menos un producto'}), 400
        
        if not data.get('forma_pago'):
            return jsonify({'error': 'Forma de pago es requerida'}), 400
        
        # Generar número de venta
        numero_venta = f"V-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}-{str(uuid.uuid4())[:8]}"
        
        # Crear venta
        venta = Venta(
            numero_venta=numero_venta,
            sucursal_id=user.sucursal_id,
            cajero_id=user_id,
            forma_pago=data['forma_pago'],
            observaciones=data.get('observaciones')
        )
        
        total_venta = Decimal('0.00')
        total_impuestos = Decimal('0.00')
        
        # Procesar detalles
        for detalle_data in data['detalles']:
            producto_id = detalle_data.get('producto_id')
            cantidad = int(detalle_data.get('cantidad', 0))
            
            if cantidad <= 0:
                return jsonify({'error': 'La cantidad debe ser mayor a 0'}), 400
            
            # Obtener producto
            producto = Producto.query.get(producto_id)
            if not producto:
                return jsonify({'error': f'Producto {producto_id} no encontrado'}), 404
            
            # Verificar stock
            stock = Stock.query.filter_by(
                producto_id=producto_id,
                sucursal_id=user.sucursal_id
            ).first()
            
            if not stock or stock.cantidad < cantidad:
                return jsonify({
                    'error': f'Stock insuficiente para {producto.nombre}. Disponible: {stock.cantidad if stock else 0}'
                }), 400
            
            # Calcular subtotal e impuesto
            precio_unitario = Decimal(str(producto.precio))
            impuesto_unitario = (precio_unitario * Decimal(str(producto.impuesto))) / Decimal('100')
            subtotal = precio_unitario * Decimal(str(cantidad))
            
            # Crear detalle
            detalle = DetalleVenta(
                producto_id=producto_id,
                cantidad=cantidad,
                precio_unitario=precio_unitario,
                impuesto_unitario=impuesto_unitario,
                subtotal=subtotal
            )
            
            venta.detalles.append(detalle)
            
            # Actualizar stock
            stock.cantidad -= cantidad
            
            # Acumular totales
            total_venta += subtotal
            total_impuestos += (impuesto_unitario * Decimal(str(cantidad)))
        
        venta.total = total_venta
        venta.total_impuestos = total_impuestos
        
        db.session.add(venta)
        db.session.commit()
        
        return jsonify({
            'message': 'Venta registrada exitosamente',
            'venta': venta.to_dict(include_detalles=True)
        }), 201
    
    except ValueError as e:
        return jsonify({'error': f'Valor inválido: {str(e)}'}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@ventas_bp.route('', methods=['GET'])
@jwt_required()
def get_ventas():
    """Obtener ventas con filtros"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        sucursal_id = request.args.get('sucursal_id')
        fecha_inicio = request.args.get('fecha_inicio')
        fecha_fin = request.args.get('fecha_fin')
        
        query = Venta.query
        
        # Filtrar por sucursal
        if user.role == 'employee':
            query = query.filter_by(sucursal_id=user.sucursal_id)
        elif sucursal_id:
            query = query.filter_by(sucursal_id=sucursal_id)
        
        # Filtrar por fechas
        if fecha_inicio:
            query = query.filter(Venta.created_at >= datetime.fromisoformat(fecha_inicio))
        if fecha_fin:
            query = query.filter(Venta.created_at <= datetime.fromisoformat(fecha_fin))
        
        ventas = query.order_by(Venta.created_at.desc()).paginate(
            page=page,
            per_page=per_page
        )
        
        return jsonify({
            'total': ventas.total,
            'pages': ventas.pages,
            'current_page': page,
            'ventas': [v.to_dict() for v in ventas.items]
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@ventas_bp.route('/<venta_id>', methods=['GET'])
@jwt_required()
def get_venta(venta_id):
    """Obtener detalle de venta"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        venta = Venta.query.get(venta_id)
        if not venta:
            return jsonify({'error': 'Venta no encontrada'}), 404
        
        # Verificar acceso: admin ve todo, empleado solo su sucursal
        if user.role == 'employee' and venta.sucursal_id != user.sucursal_id:
            return jsonify({'error': 'Acceso denegado'}), 403
        
        return jsonify(venta.to_dict(include_detalles=True)), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@ventas_bp.route('/<venta_id>/ticket', methods=['GET'])
@jwt_required()
def get_ticket(venta_id):
    """Obtener datos formateados para impresión de ticket"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        venta = Venta.query.get(venta_id)
        if not venta:
            return jsonify({'error': 'Venta no encontrada'}), 404
        
        # Verificar acceso
        if user.role == 'employee' and venta.sucursal_id != user.sucursal_id:
            return jsonify({'error': 'Acceso denegado'}), 403
        
        # Formatear ticket
        ticket = {
            'numero_venta': venta.numero_venta,
            'sucursal': venta.sucursal.nombre,
            'direccion': venta.sucursal.direccion,
            'telefono': venta.sucursal.telefono,
            'fecha': venta.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'cajero': venta.cajero.username,
            'detalles': [],
            'subtotal': 0,
            'total_impuestos': float(venta.total_impuestos),
            'total': float(venta.total),
            'forma_pago': venta.forma_pago
        }
        
        subtotal = 0
        for detalle in venta.detalles:
            detalle_dict = {
                'producto': detalle.producto.nombre,
                'cantidad': detalle.cantidad,
                'precio_unitario': float(detalle.precio_unitario),
                'subtotal': float(detalle.subtotal)
            }
            ticket['detalles'].append(detalle_dict)
            subtotal += float(detalle.subtotal)
        
        ticket['subtotal'] = subtotal
        
        return jsonify(ticket), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
