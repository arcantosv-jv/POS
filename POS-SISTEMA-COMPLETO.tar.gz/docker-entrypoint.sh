#!/bin/bash
set -e

echo "🚀 Iniciando POS Sistema..."
echo "⏳ Esperando a PostgreSQL..."

# Esperar a que PostgreSQL esté listo
while ! nc -z ${DB_HOST:-db} ${DB_PORT:-5432}; do
  echo "PostgreSQL aún no está listo. Esperando 2 segundos..."
  sleep 2
done

echo "✅ PostgreSQL está listo"

# Ejecutar migraciones
echo "🔄 Ejecutando migraciones..."
flask db upgrade || true

echo "✅ Sistema listo"

# Ejecutar el comando principal
exec "$@"
